
<?php
connect_to_database();
function connect_to_database() {
$value=array (
  'db_ip' => '127.0.0.1',
  'db_username' => 'root',
  'db_password' => 'password$$$',
  'db_values' => 
  array (
    'condition' => '',
  ),
);
	return connect_database('',$value);
}

function filterInjectString($string) {
	foreach ($string["db_attributes"] as $key => $value) {
		$string["db_attributes"][$key]=preg_replace('/[^A-Za-z0-9\-=_]/', '', $value);
	}
	return $string;
}
		
function connect_database($key, $value) {global $db;
//	print_r("<pre>");
	try {
		$db = new PDO('mysql:host='.$value["db_ip"].';',$value["db_username"],$value["db_password"]);
		$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// var_dump($db);
//		print_r("connect_database: success\n");
	} catch (PDOException $e) {
		print_r("connect_database: error\n");
		$e->getMessage();
	}
//	print_r("</pre>");
}

function create_database($key, $value) {global $db;
//	print_r("<pre>");
	try {
		// sql script.
		$sql = "CREATE DATABASE ".$value["db_name"].";";
//		print_r("create_database:".$sql."\n");
		// execute sql command.
		$cmd = $db->prepare($sql);
		$cmd->execute();
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
}

function create_table($key, $value) {global $db;
//	print_r("<pre>");
	try {
		// sql script.
		$sql = "CREATE TABLE ".$value["db_name"].".".$value["db_table_name"]."(";
		foreach ($value["db_attributes"] as $key => $value) {
			$sql .= $key." ".$value.",";   // valid string later.
		}
		$sql = rtrim($sql, ',') . ");";
//		print_r("create_table:".$sql."\n");
		// execute sql command.
		$cmd = $db->prepare($sql);
		$cmd->execute();
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
}

function insert_table($key, $value) {global $db;
//	print_r("<pre>");
	try {
		if (gettype($value["db_attributes"])!="array" || count($value["db_attributes"])<1) {
			return;
		}
		$keys="";$values="";
		// sql script.
		$sql = "INSERT INTO ".$value["db_name"].".".$value["db_table_name"]." (";
		foreach ($value["db_attributes"] as $key => $value) {
			$keys .= $key.",";
			$values .= "'".$value."',";   // valid string later.
		}
		$keys = rtrim($keys, ',');
		$values = rtrim($values, ',');
		$sql .= $keys.") VALUES (".$values.");";
		// execute sql command.
//		print_r("insert_table:".$sql."\n");
		$cmd = $db->prepare($sql);
		$cmd->execute();
		$result = $cmd->fetchObject();
//		print_r("insert_table--result:".$result."\n");
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
	}

function select_table($key, $value) {global $db;
//	print_r("<pre>");
	try {
		// sql script.
		$sql = "SELECT ";
		if (gettype($value["db_attributes"])=="array" && count($value["db_attributes"])>0) {
			foreach ($value["db_attributes"] as $k => $v) {
				$sql .= $k.","; // valid string later.
			}
		} else {
			$sql .= "*";
		}
		// print_r($sql.$value["db_name"].".".$value["db_table_name"]);
		$sql = rtrim($sql, ',');
		$sql .= " FROM ".$value["db_name"].".".$value["db_table_name"];
		if (gettype($value["db_values"])=="array" && count($value["db_values"]["condition"])>0) {
			$sql .= " WHERE ".$value["db_values"]["condition"].";";
		} else {
			$sql .= ";";
		}
		//.count($value["db_attributes"]).",".count($value["db_values"]["condition"])." "
//		print_r("select_table:".$sql."\n");
		// execute sql command.
		$cmd = $db->prepare($sql);
		$cmd->execute();
		// $result = $cmd->fetchObject();
		$result = $cmd->fetchAll();
//		print_r("select_table--result:".count($result)."\n");
		if (count($result)>0 ) {
//			print_r(json_encode($result)."\n");
			return json_encode($result);}else{return;
			}
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
}

function update_table($key, $value) {global $db;
//	print_r("<pre>");
	try {
		if (gettype($value["db_attributes"])!="array" || count($value["db_attributes"])<1) {
			return;
		}
		$sets="";$values="";
		// sql script.
		$sql = "UPDATE ".$value["db_name"].".".$value["db_table_name"]." SET ";
		foreach ($value["db_attributes"] as $k => $v) {
			$sets .= $k."="."'".$v."',";// valid string later.
		}
		$sets = rtrim($sets, ',');
		$sql .= $sets;
		if (gettype($value["db_values"])=="array" && count($value["db_values"]["condition"])>0) {
			$sql .= " WHERE ".$value["db_values"]["condition"].";";
		} else {
			$sql .= ";";
		}
		// execute sql command.
//		print_r("update_table:".$sql."\n");
		$cmd = $db->prepare($sql);
		$cmd->execute();
		$result = $cmd->fetchObject();
//		print_r("update_table--result:".$result."\n");
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
	}

function delete_table($key, $value) {global $db;
//	print_r("<pre>");
	try {
		if (gettype($value["db_values"])!="array" || count($value["db_values"])<1) {
			return;
		}
		$sets="";$values="";
		// sql script.
		$sql = "DELETE FROM ".$value["db_name"].".".$value["db_table_name"];
		if (gettype($value["db_values"])=="array" && count($value["db_values"]["condition"])>0) {
			$sql .= " WHERE ".$value["db_values"]["condition"].";";
		} else {
			$sql .= ";";
		}
		// execute sql command.
//		print_r("delete_table:".$sql."\n");
		$cmd = $db->prepare($sql);
		$cmd->execute();
		$result = $cmd->fetchAll();
//		print_r("delete_table--result:".count($result)."\n");
	} catch (PDOException $e) {
		$e->getMessage();
	}
//	print_r("</pre>");
}

?>
